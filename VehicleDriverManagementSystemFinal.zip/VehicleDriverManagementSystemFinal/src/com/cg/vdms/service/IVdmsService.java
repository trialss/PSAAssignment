package com.cg.vdms.service;

import java.util.List;

import com.cg.vdms.dto.Driver;
import com.cg.vdms.dto.Vehicle;
import com.cg.vdms.exception.DriverException;

public interface IVdmsService
{
	public String addDriver(Driver driver) throws DriverException;
	public String addVehicle(Vehicle vehicle);
	
	public List<String> getAllEmail();
	public List<String> getAllPass();
	
	public boolean validateEmail(String email);
	public boolean validatePass(String password);
	
	public Driver loginDriver(String email, String password) throws DriverException;
	
	public Driver DriverInfo(Integer driveId) throws DriverException;
	public Vehicle VehicleInfo(Integer vehicleId) throws DriverException;
	
	public void updateDriver(Driver driver);
	public void updateDriverContact(Double driverNum, Integer id);
	public void updateVehicleColor(Integer id, String color);
}
