package com.cg.vdms.service;

import java.util.List;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.vdms.dao.IVdmsDao;
import com.cg.vdms.dto.Driver;
import com.cg.vdms.dto.Vehicle;
import com.cg.vdms.exception.DriverException;

@Service("vdmsService")
@Transactional
public class IVdmsServiceImpl implements IVdmsService
{
	@Autowired IVdmsDao vdmsdao;

	@Override
	public List<String> getAllEmail() 
	{
		return vdmsdao.getAllEmail();
	}

	@Override
	public List<String> getAllPass() 
	{
		return vdmsdao.getAllPass();
	}

	@Override
	public boolean validateEmail(String email) 
	{
		List<String>allIds=(List<String>)vdmsdao.getAllEmail();
		for(String i:allIds)
		{
			if(i.equals(email))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean validatePass(String password) 
	{
		List<String>allPass=(List<String>)vdmsdao.getAllPass();
		for(String i:allPass)
		{
			if(i.equals(password))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public String addDriver(Driver driver) throws DriverException 
	{
		return vdmsdao.addDriver(driver);
	}

	@Override
	public Driver DriverInfo(Integer driveId) throws DriverException {
		
		return vdmsdao.DriverInfo(driveId);
	}

	@Override
	public void updateDriver(Driver driver) {
		vdmsdao.updateDriver(driver);
	}

	@Override
	public Driver loginDriver(String email, String password) throws DriverException {
		return vdmsdao.loginDriver(email, password);
	}

	@Override
	public void updateDriverContact(Double driverNum, Integer id) {
		vdmsdao.updateDriverContact(driverNum, id);
		
	}

	@Override
	public String addVehicle(Vehicle vehicle) {
		return vdmsdao.addVehicle(vehicle);
	}

	@Override
	public Vehicle VehicleInfo(Integer vehicleId) throws DriverException {
		return vdmsdao.VehicleInfo(vehicleId);
	}

	@Override
	public void updateVehicleColor(Integer id, String color) {
		vdmsdao.updateVehicleColor(id, color);
	}


}
