package com.cg.vdms.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.vdms.dto.Driver;
import com.cg.vdms.exception.DriverException;
import com.cg.vdms.service.IVdmsService;
@Controller
public class DriverController
{
	@Autowired IVdmsService vdmsService;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "login";
	}
	@RequestMapping(value="frmlogin",method=RequestMethod.POST)
	public ModelAndView getOptions(@RequestParam("username")String emailid,@RequestParam("password")String pswrd, HttpServletRequest request)
	{
			try
			{
				Driver d=vdmsService.loginDriver(emailid, pswrd);
				System.out.println("admin value"+d.getAdmin());
				if(d.getAdmin().equals("Y"))
				{
					return new ModelAndView("Options","admin",d.getAdmin());
				}
				//if not admin, shows direct info
				else{
					return new ModelAndView("DriverInfo","driver",d);
				}
			}
			catch(DriverException de){
				return new ModelAndView("login","msg",de.getMessage());
			}		
	}
	@RequestMapping(value="driver")
	public String driverMenu()
	{
		return "driverOptions";
	}
	
	@RequestMapping(value="adddriver", method=RequestMethod.GET)
	public String driverOptions(@ModelAttribute("drv")Driver driver)
	{
		return "AddDriver";
	}
	@RequestMapping(value="insertData",method=RequestMethod.POST)
	public ModelAndView addDriverInfo(@Valid@ModelAttribute("drv")Driver driver, BindingResult result) throws DriverException
	{
//		if(result.hasErrors()) {
//			return new ModelAndView("AddDriver");
//		}
		//else {	
		System.out.println("Driver values" + driver.toString());
		String dId = vdmsService.addDriver(driver);
		if(dId != null)
			return new ModelAndView("success", "msg", "Successfully Inserted");
		else
			return new ModelAndView("Error","msg","Insertion faliure");
		//}
	}
	@RequestMapping(value="getdriverInfo", method=RequestMethod.GET)
	public ModelAndView GetDriverDetails()
	{
//		return new ModelAndView("DriverDetails","getInfoFor","findDriver");
		return new ModelAndView("DriverId");
	}
	@RequestMapping(value="getDriver", method=RequestMethod.POST)
	public ModelAndView printDriverDetails(@RequestParam("id") Integer driverId)
	{
		System.out.println("driver id" + driverId);
		
		Driver d = null;
		try {
			d = vdmsService.DriverInfo(driverId);
			return new ModelAndView("DriverInfo","driver",d);
		} catch (DriverException e) {
			e.printStackTrace();
			return new ModelAndView("DriverId","msg",e.getMessage());
		}	
	}
	
	@RequestMapping(value="updateno")
	public ModelAndView updateDriverNo(@RequestParam("did") String driverId, HttpServletRequest request)
	{
		request.getSession(true).setAttribute("uid", driverId);
		return new ModelAndView("UpdateDriverNo");
	}
	@RequestMapping(value="updatecontact")
	public ModelAndView updateDriverNum(@RequestParam("num") Double driverNum, HttpServletRequest request )
	{
		String id = (String) request.getSession(false).getAttribute("uid");
		System.out.println("driver id inside session" + id + " " + driverNum);
		int dId = Integer.valueOf(id);
		vdmsService.updateDriverContact(driverNum,dId);
		return new ModelAndView("success", "msg", "contact number successfully updated");
	}

	@RequestMapping(value="updatedriver",method=RequestMethod.GET) 
	public ModelAndView updateDriver(@ModelAttribute("drive")Driver driver) {
			return new ModelAndView("updatepersonaldata");
		}
	
	@RequestMapping(value="updateData",method=RequestMethod.POST)
	public ModelAndView updateDriverDetails(@ModelAttribute("drive")Driver driver,BindingResult result)
	{
		vdmsService.updateDriver(driver);
		return new ModelAndView("success","msg","Driver Details are updated Successfully");
	}
//	@RequestMapping(value="updateData", method=RequestMethod.POST)
//	public ModelAndView updateDriverDetails(@ModelAttribute("drv")Driver driver, BindingResult result)throws DriverException
//	{
//
//		try {
//			vdmsService.updateDriver(d);
//		}catch(DriverException de) {
//			e.printStacTrace();
//			
//		}
////			d = vdmsService.DriverInfo(driverId);
////			return new ModelAndView("DriverInfo","driver",d);
////		} catch (DriverException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////			return new ModelAndView("DriverDetails","msg",e.getMessage());	
////		}
//	}
	
	
	//redirectiong to vehicle controller
	@RequestMapping(value="vehicle",method=RequestMethod.GET)
	public ModelAndView redirectController()
	{
		return new ModelAndView("redirect:veh");
	}
}
